var SpriteSheet = function (image, sw, sh) {

    "use strict";
    var self = this;
    self.name = null;
    self.image = image;
    self.sw = sw;
    self.sh = sh;

};